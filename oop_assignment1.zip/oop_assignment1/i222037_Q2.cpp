//Abdul Wasay
//Ai-C
//22i-2037
#include <iostream>
using namespace std;
void printPattern(int n, int i, int j, int value) {
    if (i >= n) {
        return;
    }

    if (j <= i) {
        cout << value << " ";
        printPattern(n, i, j + 1, 1);
    } else {
        cout << endl;
        printPattern(n, i + 1, 0, n - i - 1);
    }
}

int main() {
    int n,i=0,j=0;
    cout << "Enter the number of rows for the pattern: ";
    cin >> n;
    cout << "Pattern:" << endl;
    printPattern(n, i, j, n);
    return 0;
}

