#include "jungle.h"
#include "animal.h"
#include<iostream>
#include<string>
//constructor body
jungle::jungle(int initialCapacity) { 
    count = 0;
    capacity = initialCapacity;
    //dma
    p = new animal[capacity];
}
//function for adding animal
void jungle::addAnimal() {
    if (count < capacity) {
        string name, species;
        int age;
        bool availability;

        cout << "Enter the name of the animal: ";
        cin >> name;

        cout << "Enter the species of the animal: ";
        cin >> species;

        cout << "Enter the age of the animal: ";
        cin >> age;

        cout << "Is the animal available (1 for yes, 0 for no): ";
        cin >> availability;

        p[count] = animal(name, species, age, availability);
        count++;
    }
    else {
        cout << "Jungle full!" << endl;
        exit;
    }
}

//for removing
void jungle::remove() {
    int index;
    cout << "Enter the number of the animal you want to remove: ";
    cin >> index;
    index -= 1;
    if (index >= 0 && index < count) {
        // Move all animals after the removed one to fill the gap
        for (int i = index; i < count - 1; i++) {
            p[i] = p[i + 1];
        }
        count--;

        cout << "Animal removed successfully." << endl;
    }
    else {
        cout << "Invalid animal number. Please enter a valid number." << endl;
    }
}
//for searching
void jungle::search() {
    for (int i = 0; i < count; i++) {
        p[i].sortAnimalsbyCriteria();
    }

}
//for sorting
void jungle::sort() const {
    int criteria;
    cout << "1 for sorting via age. 2 for name. 3 for species." << endl;
    cin >> criteria;

    if (criteria < 1 || criteria > 3) {
        cout << "Invalid criteria. Please enter 1, 2, or 3." << endl;
        return;
    }

    if (count == 0) {
        cout << "No animals in the jungle to sort." << endl;
        return;
    }

    // Make a copy of the 'p' array to sort
    animal* sortedAnimals = new animal[count];
    for (int i = 0; i < count; i++) {
        sortedAnimals[i] = p[i];
    }

    // Sort the 'sortedAnimals' array based on the chosen criteria
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (criteria == 1 && sortedAnimals[j].getAge() > sortedAnimals[j + 1].getAge()) { 
                swap(sortedAnimals[j], sortedAnimals[j + 1]);
            }
            else if (criteria == 2 && sortedAnimals[j].getName() > sortedAnimals[j + 1].getName()) { 
                swap(sortedAnimals[j], sortedAnimals[j + 1]);
            }
            else if (criteria == 3 && sortedAnimals[j].getSpecie() > sortedAnimals[j + 1].getSpecie()) { 
                swap(sortedAnimals[j], sortedAnimals[j + 1]);
            }
        }
    }

    // Display the sorted animals
    for (int i = 0; i < count; i++) {
        sortedAnimals[i].displayInfo();
    }

    delete[] sortedAnimals;
}
//for displaying info in  jungle class
void jungle::displayinfo() const {
    for (int i = 0; i < count; i++) {
        p[i].displayInfo();
    }
}
//to display total available animals
void jungle::displayTotalAvailable() {
    int totalAvailable = 0;
    for (int i = 0; i < count; i++) {
        if (p[i].checkAvailability()) {
            totalAvailable++;
        }
    }
    cout << endl;
    cout << "Total available animals: " << totalAvailable << endl;
}



//destructor and deletion of dynamic array on animal object in jungle class
jungle::~jungle() {
    delete[] p;
}
