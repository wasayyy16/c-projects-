#include "animal.h"
#include "jungle.h"
#include <iostream>
#include <string>


//constructors bodies
animal::animal() {
    name = " ";
    specie = " ";
    age = 0;
    availability = 1;
    number++;
}

animal::animal(string n, string s, int a, bool avl) {
    name = n;
    specie = s;
    age = a;
    availability = avl;
    number++;
}

animal::animal(const animal& other) {
    name = other.name;
    specie = other.specie;
    age = other.age;
    availability = other.availability;
    number++;
}
//body of getters and setters
string animal::getName() {
    return name;
}
void animal::setName(string n) {
    name = n;
}
string animal::getSpecie() {
    return specie;
}
void animal::setSpecie(string s) {
    specie = s;
}
int animal::getAge() {
    return age;
}
void animal::setAge(int a) {
    age = a;
}
bool animal::getAVL() {
    return availability;
}
void animal::setAvl(bool avl) {
    availability = avl;
}

//checking availability
bool animal::checkAvailability() const {
    if (availability == 0) {
        cout << "Animal is not available." << endl;
        return 0;
    }
    else if (availability == 1) {
        cout << "Animal is available." << endl;
        return 1;
    }
    else {
        cout << "Invalid Input." << endl;
    }
}
//for displaying info
void animal::displayInfo() const {
    cout << "Details for Animal are : " << endl;
    cout << "Name : " << name << endl;
    cout << "Species : " << specie << endl;
    cout << "Age : " << age << endl;
    checkAvailability();
}
//for displaying info
void displayAnimalInfo(animal& other) {
    cout << endl;
    cout << "Details for Animal are : " << endl;
    cout << "Name : " << other.name << endl;
    cout << "Species : " << other.specie << endl;
    cout << "Age : " << other.age << endl;
    other.checkAvailability();
    cout << endl;
}
//for sorting
void animal::sortAnimalsbyCriteria() {
    int aww;
    cout << "1 for searching via age. 2 for name. 3 for specie,any other key to exit." << endl;
    cin >> aww;
    if (aww == 1) {
        int ageIN;
        cout << "Enter the required age : ";
        cin >> ageIN;
        if (ageIN == age) {
            cout << "Result found!" << endl;
            displayInfo();
        }
        else {
            cout << "No animal of same age found!" << endl;
            exit;
        }
    }
    else if (aww == 2) {
        string namIN; 
        cout << "Enter the required name : ";
        cin >> namIN;
        if (namIN == name) {
            cout << "Result found!" << endl;
            displayInfo();
        }
        else {
            cout << "No animal of the same name found!" << endl;
        }
    }

    else if (aww == 3) {
    
        string specieIN; 
        cout << "Enter the required specie : ";
        cin >> specieIN;
        if (specieIN == specie) {
            cout << "Result found!" << endl;
            displayInfo();
        }
        else {
            cout << "No animal of the same specie found!" << endl;
        
    }

    }
    else {
        cout << "Invalid Input." << endl;

    }
}
//destructor body
animal::~animal() {
   
}




