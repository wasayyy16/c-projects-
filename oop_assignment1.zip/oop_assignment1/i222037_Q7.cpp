#include <iostream>
#include <cstring>
using namespace std;

const int s = 500;

void findUniqueWords(const char* sentence, char uniqueWords[s][s], int& uniqueWordCount) {
    char* token = strtok(const_cast<char*>(sentence), " ");

    while (token != 0) {
        bool isUnique = true;

        for (int i = 0; i < uniqueWordCount; i++) {
            if (strcmp(uniqueWords[i], token) == 0) {
                isUnique = false;
                break;
            }
        }

        if (isUnique) {
            strcpy(uniqueWords[uniqueWordCount], token);
            uniqueWordCount++;

            if (uniqueWordCount >= s) {
                cout << "Too many unique words. Increase the size of the array." << endl;
                break;
            }
        }

        token = strtok(0, " ");
    }
}

int main() {
    char sentence[s];
    cout << "Input the sentence: " << endl;
    cin.getline(sentence, s);

    char uniqueWords[s][s];
    int uniqueWordCount = 0;

    findUniqueWords(sentence, uniqueWords, uniqueWordCount);

    cout << "Unique words in the sentence:" << endl;
    for (int i = 0; i < uniqueWordCount; i++) {
        cout << uniqueWords[i] << endl;
    }

    return 0;
}


