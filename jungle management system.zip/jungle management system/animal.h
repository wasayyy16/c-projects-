#pragma once
#include <iostream>
#include <string>


using namespace std; 

class animal
{
private :
    //datamembers are set to be private
    string name;
    string specie;
    int age;
    bool availability;
public : 
    int number=0,destructor=1;
    //constructors
    animal();
    animal(string n,string s,int a,bool avl);
    animal(const animal& other);
    //getters and setters
    string getName();
    void setName(string n);
    string getSpecie();
    void setSpecie(string s);
    int getAge();
    void setAge(int a);
    bool getAVL();
    void setAvl(bool avl);
    //member functions
    bool checkAvailability() const;
    void displayInfo() const;
    void sortAnimalsbyCriteria();
    friend void displayAnimalInfo(animal& other);
    //destructor
    ~animal();
};
