//Abdul Wasy
//22i-2037
//Ai-C
#include "animal.h"
#include "jungle.h"
#include <iostream>
#include <string>
#include <windows.h>
using namespace std;

int main() {
    // Loading bar
    system("cls");
    system("color 78");
    cout << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl;
    cout << "\t\t\t\t\t\t loading." << endl;
    char w = 219;
    cout << "\t\t\t\t\t";
    for (int i = 0; i < 23; i++) {
        cout << w;
        Sleep(100);
    }
    cout << endl << endl << endl << endl;
    cout << "\t\t\t\t\tWELCOME TO JUNGLE'S MENU!" << endl;
    Sleep(3000);
    system("cls");

    int x;
     jungle j;
     int ex = 0;
     
    while (ex == 0) {
        cout << endl;
        cout << "1 for adding animal. " << endl;
        cout << "2 for removing animal from the jungle for research. " << endl;
        cout << "3 for searching for an animal. " << endl;
        cout << "4 for displaying all the animals' information. " << endl;
        cout << "5 for checking the total number of available animals. " << endl;
        cout << "6 for sorting. " << endl;
        cout << "7 for exitting." << endl;
        cin >> x;
        cout << endl;
        switch (x) {
        case 1:
            // Implement adding an animal logic here
            j.addAnimal();
            break;

        case 2:
            // Implement removing an animal logic here
            j.remove();
            break;

        case 3:
            // Implement searching for an animal logic here
            j.search();
            break;
            j.sort();
        case 4://displaying info
            j.displayinfo();
            break;

        case 5:
            // Implement checking the total number of available animals logic here
            j.displayTotalAvailable();
            break;
        case 6:
            //sorting via any criteria
            j.sort();
            break;
        case 7:
            //exiting the program
            ex++;
            cout << "You are exiting the program." << endl;
            break;
        default:
            cout << "Invalid Input!" << endl;
            break;
        }
    }
    return 0;
}
