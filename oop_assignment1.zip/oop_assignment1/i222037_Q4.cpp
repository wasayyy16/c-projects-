//Abdul Wasay
//Ai-C
//22i-2037
#include<iostream>
using namespace std;
void FindOccurances(int *arr, int n, int i) {
    if (i >= n) {
        return;
    }
    else{
    int temp = arr[i];
    int count = 0;
    
    for (int j = 0; j < n; j++) {
        if (arr[j] == temp) {
            count++;
        }
    }

    cout << " \t" << temp << "  \t\t" << count << endl;
    
    FindOccurances(arr, n, i + 1);
}
}

int main() {
    const int n = 6;
    int i=0;
    int* arr = new int[n];

    cout << "Input the elements of the array:" << endl;
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    cout << "Input array is: " << endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
    cout<<"The occurences of elements are : "<<endl<<endl;
cout << "\t" << "Element" << "\t\t" << "Occurrences" << endl<<endl;
    FindOccurances(arr, n, i);

    delete[] arr;
    return 0;
}
