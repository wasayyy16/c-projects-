#pragma once
#include "animal.h"
#include <iostream>
#include <string>

using namespace std; 

class jungle {
private:
    //data members
    animal* p;
    int count;
    int capacity;

public:
    //constructor
    jungle(int initialCapacity = 10);
    //member functions
    void addAnimal();
    void remove();
    void sort() const;
    void search();
    void displayinfo() const;
    void displayTotalAvailable();
    //destructor
    ~jungle();
};



